/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padrãosingletonapresentação;

/**
 *
 * @author fernando
 */
public class FabricadeParafuso {
    
     public static FabricadeParafuso instancia;
    
    public String modelo;
    
    protected FabricadeParafuso(){
    
        
        
    }
    
     public static FabricadeParafuso getInstancia() {
        if (instancia == null){
            instancia = new FabricadeParafuso();
        }
        return instancia;
    }
}
