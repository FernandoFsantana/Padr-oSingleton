/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package padrãosingletonapresentação;

/**
 *
 * @author fernando
 */
public class PadrãoSingletonApresentação {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
      FabricadeParafuso exemplo = new FabricadeParafuso();
       
        
        exemplo = FabricadeParafuso.getInstancia();
        exemplo.modelo = "Parafuso Francês";
        System.out.println(exemplo.modelo);
        
        FabricadeParafuso exemplo2 = new FabricadeParafuso();
         exemplo2 = FabricadeParafuso.getInstancia();
         exemplo2.modelo = "Parafuso Sextavado";
         
         FabricadeParafuso exemplo3 = new FabricadeParafuso();
         exemplo3 = FabricadeParafuso.getInstancia();
         exemplo3.modelo = "Parafuso Auto Atarraxante";
        
        System.out.println(exemplo3.modelo); 
        System.out.println(exemplo2.modelo);
        System.out.println(exemplo.modelo);
        
        
//        O Padrão Singleton tem como definição garantir que uma classe tenha apenas uma
//        instância de si mesma e que forneça um ponto global de acesso a ela. Ou seja, uma 
//        classe gerencia a própria instância dela além de evitar que qualquer outra classe 
//        crie uma instância dela.
        
    }
    
}
